import { PGlite } from 'https://cdn.jsdelivr.net/npm/@electric-sql/pglite@0.5.15/dist/index.js';
import { worker } from 'https://cdn.jsdelivr.net/npm/@electric-sql/pglite@0.5.15/dist/worker/index.js';

// This worker owns the PostgreSQL WASM runtime and its small synthetic practice
// database. Query execution stays off the page's main thread.
worker({
  async init(options) {
    const db = new PGlite(options.dataDir ? { dataDir: options.dataDir } : {});
    await db.waitReady;
    if (options.meta && options.meta.seed) {
      await db.exec(options.meta.seed);
    }
    return db;
  },
});
