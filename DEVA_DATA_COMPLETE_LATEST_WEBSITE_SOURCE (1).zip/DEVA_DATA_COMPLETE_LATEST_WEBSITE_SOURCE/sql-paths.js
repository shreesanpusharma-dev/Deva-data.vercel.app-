(() => {
 const root=document.querySelector("[data-sql-progress]");
 if(!root)return;
 const key="deva-sql-progress-"+root.getAttribute("data-sql-progress")+"-v1";
 const checks=Array.from(root.querySelectorAll("[data-sql-done]"));
 const bar=root.querySelector("[data-progress-bar]"),count=root.querySelector("[data-progress-count]");
 let saved=[];try{saved=JSON.parse(localStorage.getItem(key)||"[]")}catch(_){}
 checks.forEach((el,i)=>el.checked=saved.includes(i));
 const update=()=>{
  const done=checks.filter(el=>el.checked).length;
  if(bar)bar.style.width+(Math.round(done/checks.length*100)+"%");
  if(bar)bar.style.width=Math.round(done/checks.length*100)+"%";
  if(count)count.textContent=done+" / "+checks.length+" lessons completed";
  try{localStorage.setItem(key,JSON.stringify(checks.map((el,i)=>el.checked?i:-1).filter(i=>i>=0)))}catch(_){}
 };
 checks.forEach(el=>el.addEventListener("change",update));update();
})();