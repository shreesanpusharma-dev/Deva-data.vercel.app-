# Data lineage and reproducibility

```text
Synthetic source records
  data/retail_orders.csv
          │
          ├── setup.sql -> portfolio_retail.orders
          │                  │
          │                  └── v_order_financials (shared metric logic)
          │                              │
          │                              ├── queries.sql -> analytical result sets
          │                              └── quality_checks.sql -> diagnostics/assertions
          │
          └── scripts/validate_data.py -> validates source rows and output CSVs

Checked result exports
  outputs/city_revenue.csv
  outputs/city_product_revenue.csv
  outputs/customer_segments.csv
  outputs/cities_over_70000.csv
  outputs/order_status_summary.csv
  outputs/revenue_reconciliation.csv
```

The flat CSV and SQL seed are two representations of the same synthetic source records. The standard-library validator checks the CSV's row-level rules and verifies that each committed result CSV reconciles to independently recalculated figures. The SQL quality script performs database-side checks after setup. No external data source, API, credential or secret is required.

## Reproduction order

1. Verify the archive and its `checksums.sha256` manifest if you need file-integrity assurance.
2. Run `setup.sql` in a separate practice database.
3. Run `queries.sql` to inspect the analytical results.
4. Run `quality_checks.sql` to check data validity and core totals.
5. Optionally run `py scripts\validate_data.py` to verify the flat-file source and exported CSV results.
