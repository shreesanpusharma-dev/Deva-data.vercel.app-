#!/usr/bin/env python3
"""Validate the synthetic retail CSV and checked result exports using stdlib only."""
from __future__ import annotations
import csv
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "retail_orders.csv"
OUT = ROOT / "outputs"
D = Decimal
Q = lambda x: D(x).quantize(D("0.01"), rounding=ROUND_HALF_UP)
EXPECTED_HEADERS = ["order_id", "order_date", "customer_id", "city", "product", "quantity", "unit_price", "discount_percent", "order_status"]
ALLOWED_STATUSES = {"Delivered", "Cancelled", "Returned"}


def read_csv(path: Path):
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def main() -> int:
    rows = read_csv(DATA)
    require(rows, "Source CSV has no data rows")
    require(list(rows[0].keys()) == EXPECTED_HEADERS, "Source CSV headers or order differ from the data contract")
    require(len(rows) == 12, f"Expected 12 sample rows; got {len(rows)}")
    ids = [r["order_id"] for r in rows]
    require(len(ids) == len(set(ids)), "Duplicate order_id values found")

    parsed = []
    for line_no, r in enumerate(rows, start=2):
        require(all(r[k].strip() for k in EXPECTED_HEADERS), f"Blank required value at CSV line {line_no}")
        require(r["order_status"] in ALLOWED_STATUSES, f"Unsupported status at line {line_no}")
        qty = int(r["quantity"])
        price = D(r["unit_price"])
        discount_pct = D(r["discount_percent"])
        require(qty > 0, f"Non-positive quantity at line {line_no}")
        require(price >= 0, f"Negative unit price at line {line_no}")
        require(D("0") <= discount_pct <= D("100"), f"Invalid discount at line {line_no}")
        gross = Q(D(qty) * price) if r["order_status"] == "Delivered" else D("0.00")
        discount = Q(gross * discount_pct / D("100")) if r["order_status"] == "Delivered" else D("0.00")
        net = Q(gross - discount)
        parsed.append({**r, "quantity_int": qty, "gross": gross, "discount": discount, "net": net})

    delivered = [r for r in parsed if r["order_status"] == "Delivered"]
    require(len(delivered) == 10, f"Expected 10 delivered rows; got {len(delivered)}")
    require(sum(1 for r in parsed if r["order_status"] == "Cancelled") == 1, "Expected one cancelled row")
    require(sum(1 for r in parsed if r["order_status"] == "Returned") == 1, "Expected one returned row")
    gross_total = Q(sum((r["gross"] for r in parsed), D("0.00")))
    discount_total = Q(sum((r["discount"] for r in parsed), D("0.00")))
    net_total = Q(sum((r["net"] for r in parsed), D("0.00")))
    require(gross_total == D("231600.00"), f"Gross reconciliation mismatch: {gross_total}")
    require(discount_total == D("15680.00"), f"Discount reconciliation mismatch: {discount_total}")
    require(net_total == D("215920.00"), f"Net revenue reconciliation mismatch: {net_total}")

    city = {}
    cp = {}
    customers = {}
    statuses = {s: 0 for s in ["Delivered", "Cancelled", "Returned"]}
    for r in parsed:
        statuses[r["order_status"]] += 1
    for r in delivered:
        c = city.setdefault(r["city"], {"orders": 0, "customers": set(), "net": D("0.00")})
        c["orders"] += 1
        c["customers"].add(r["customer_id"])
        c["net"] += r["net"]
        cp[(r["city"], r["product"])] = cp.get((r["city"], r["product"]), D("0.00")) + r["net"]
        customers[r["customer_id"]] = customers.get(r["customer_id"], D("0.00")) + r["net"]

    expected_city = [[k, v["orders"], len(v["customers"]), f"{Q(v['net']):.2f}"] for k, v in sorted(city.items(), key=lambda kv: (-kv[1]["net"], kv[0]))]
    actual_city = [[r["city"], int(r["delivered_orders"]), int(r["unique_customers"]), f"{D(r['net_revenue_inr']):.2f}"] for r in read_csv(OUT / "city_revenue.csv")]
    require(actual_city == expected_city, "outputs/city_revenue.csv does not match the source data")

    expected_cp = [[city_name, product, f"{Q(value):.2f}"] for (city_name, product), value in sorted(cp.items(), key=lambda kv: (kv[0][0], -kv[1], kv[0][1]))]
    actual_cp = [[r["city"], r["product"], f"{D(r['net_revenue_inr']):.2f}"] for r in read_csv(OUT / "city_product_revenue.csv")]
    require(actual_cp == expected_cp, "outputs/city_product_revenue.csv does not match the source data")

    expected_segments = []
    for customer, value in sorted(customers.items(), key=lambda kv: (-kv[1], kv[0])):
        label = "High Value" if value >= D("40000") else "Medium Value" if value >= D("15000") else "Low Value"
        expected_segments.append([customer, f"{Q(value):.2f}", label])
    actual_segments = [[r["customer_id"], f"{D(r['net_revenue_inr']):.2f}", r["customer_segment"]] for r in read_csv(OUT / "customer_segments.csv")]
    require(actual_segments == expected_segments, "outputs/customer_segments.csv does not match the source data")

    expected_above = [r for r in expected_city if D(r[3]) > D("70000")]
    actual_above = [[r["city"], int(r["delivered_orders"]), int(r["unique_customers"]), f"{D(r['net_revenue_inr']):.2f}"] for r in read_csv(OUT / "cities_over_70000.csv")]
    require(actual_above == expected_above, "outputs/cities_over_70000.csv does not match the source data")

    actual_status = [[r["order_status"], int(r["record_count"]), r["revenue_treatment"]] for r in read_csv(OUT / "order_status_summary.csv")]
    expected_status = [[s, statuses[s], "Included" if s == "Delivered" else "Excluded"] for s in ["Delivered", "Cancelled", "Returned"]]
    require(actual_status == expected_status, "outputs/order_status_summary.csv does not match the source data")

    actual_recon = [[r["metric"], f"{D(r['amount_inr']):.2f}"] for r in read_csv(OUT / "revenue_reconciliation.csv")]
    expected_recon = [["delivered_gross_value", f"{gross_total:.2f}"], ["delivered_discounts", f"{discount_total:.2f}"], ["delivered_net_sales_revenue", f"{net_total:.2f}"]]
    require(actual_recon == expected_recon, "outputs/revenue_reconciliation.csv does not match the source data")

    print("PASS  source schema, required values, unique IDs and domain checks")
    print("PASS  12 source rows and expected order-status counts")
    print("PASS  gross value, discounts and net revenue reconciliation")
    print("PASS  city, city/product, customer segment, threshold and status outputs")
    print(f"PASS  delivered net sales revenue = INR {net_total:,.2f}")
    print("All Python data checks passed. PostgreSQL quality_checks.sql should also be run in PostgreSQL.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (AssertionError, KeyError, ValueError) as exc:
        print(f"FAIL  {exc}", file=sys.stderr)
        raise SystemExit(1)
