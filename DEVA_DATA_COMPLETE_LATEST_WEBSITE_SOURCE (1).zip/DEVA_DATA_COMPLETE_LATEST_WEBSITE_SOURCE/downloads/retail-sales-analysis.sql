-- Retail Sales & Revenue Analysis | version 1.1.0
-- Run setup.sql first. All metric definitions come from the shared view.
-- Dataset is synthetic. Currency is INR.

-- 1. Inspect the source records.
SELECT *
FROM portfolio_retail.orders
ORDER BY order_date, order_id;

-- 2. Review the row-level revenue calculations.
SELECT
    order_id, city, product, order_status,
    delivered_gross_value,
    delivered_discount_value,
    delivered_net_revenue
FROM portfolio_retail.v_order_financials
ORDER BY order_id;

-- 3. City-level KPIs. One delivered row is one order record in this dataset.
SELECT
    city,
    COUNT(*) AS delivered_order_records,
    COUNT(DISTINCT customer_id) AS unique_customers,
    SUM(delivered_gross_value) AS gross_value_inr,
    SUM(delivered_discount_value) AS discounts_inr,
    SUM(delivered_net_revenue) AS net_sales_revenue_inr
FROM portfolio_retail.v_order_financials
WHERE order_status = 'Delivered'
GROUP BY city
ORDER BY net_sales_revenue_inr DESC, city;

-- 4. Net sales by city and product.
SELECT
    city,
    product,
    SUM(delivered_net_revenue) AS net_sales_revenue_inr
FROM portfolio_retail.v_order_financials
WHERE order_status = 'Delivered'
GROUP BY city, product
ORDER BY city, net_sales_revenue_inr DESC, product;

-- 5. Cities exceeding the practice threshold of INR 70,000.
SELECT
    city,
    SUM(delivered_net_revenue) AS net_sales_revenue_inr
FROM portfolio_retail.v_order_financials
WHERE order_status = 'Delivered'
GROUP BY city
HAVING SUM(delivered_net_revenue) > 70000
ORDER BY net_sales_revenue_inr DESC;

-- 6. Customer segments. Practice-only cut-offs: High >= 40,000;
-- Medium >= 15,000 and < 40,000; Low < 15,000.
WITH customer_revenue AS (
    SELECT customer_id, SUM(delivered_net_revenue) AS net_sales_revenue_inr
    FROM portfolio_retail.v_order_financials
    WHERE order_status = 'Delivered'
    GROUP BY customer_id
)
SELECT
    customer_id,
    net_sales_revenue_inr,
    CASE
        WHEN net_sales_revenue_inr >= 40000 THEN 'High Value'
        WHEN net_sales_revenue_inr >= 15000 THEN 'Medium Value'
        ELSE 'Low Value'
    END AS customer_segment
FROM customer_revenue
ORDER BY net_sales_revenue_inr DESC, customer_id;

-- 7. Order-status mix. This includes statuses excluded from revenue.
SELECT
    order_status,
    COUNT(*) AS record_count,
    SUM(delivered_net_revenue) AS included_net_revenue_inr
FROM portfolio_retail.v_order_financials
GROUP BY order_status
ORDER BY record_count DESC, order_status;

-- 8. Revenue reconciliation: gross less discounts equals net revenue.
SELECT
    SUM(delivered_gross_value) AS delivered_gross_value_inr,
    SUM(delivered_discount_value) AS delivered_discounts_inr,
    SUM(delivered_net_revenue) AS delivered_net_sales_revenue_inr
FROM portfolio_retail.v_order_financials;
