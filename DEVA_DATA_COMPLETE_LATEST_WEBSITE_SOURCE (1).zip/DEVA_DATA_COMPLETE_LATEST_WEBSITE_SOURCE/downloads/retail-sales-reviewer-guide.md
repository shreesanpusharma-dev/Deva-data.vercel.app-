# Reviewer guide

## What a reviewer can verify

- A clearly stated grain: one row per synthetic order record.
- A dedicated schema and a table with primary-key and domain constraints.
- A single view that defines delivered gross value, discount value and net sales consistently.
- Analytical queries for city, product, customer and status summaries.
- Independent CSV outputs and a reconciliation between gross value, discounts and net sales.
- Automated assertions in PostgreSQL and an optional Python standard-library validator.

## Main result

Delhi has the highest net sales value in this 12-row sample (INR 83,220), followed by Bengaluru (INR 66,900) and Kolkata (INR 65,800). The city figures sum to INR 215,920, the same as delivered net sales across the dataset.

## Questions to ask before trusting a real sales report

1. What does one row represent: an order, an order item, an invoice or a payment?
2. Does delivered mean shipped, delivered to customer, invoiced, or paid?
3. How are partial returns, refunds, cancellations, tax, shipping and chargebacks recorded?
4. Can city refer to billing, shipping, store, or customer residence?
5. Are discounts stored at item level or order level, and can they be stacked?
6. Does `COUNT(*)` represent orders, or should `COUNT(DISTINCT order_id)` be used?

## Honest limitations

This is a small synthetic learning project, not a commercial analysis. Twelve rows cannot support market, seasonality, customer lifetime value or operational performance claims. The sample has no payment, inventory, cost, tax or refund tables. No production database, API, dashboard or client deployment is claimed.
