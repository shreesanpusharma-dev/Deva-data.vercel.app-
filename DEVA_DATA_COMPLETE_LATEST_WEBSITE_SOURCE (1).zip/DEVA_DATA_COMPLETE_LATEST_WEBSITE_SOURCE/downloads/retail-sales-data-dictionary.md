# Data dictionary

All records are synthetic. The dataset grain is one row per simplified order record, not one product line in a production order-management model.

| Column | PostgreSQL type | Meaning | Validation / unit |
|---|---|---|---|
| `order_id` | INTEGER | Unique order-record identifier | Primary key; not null |
| `order_date` | DATE | Date the sample order was placed | Not null |
| `customer_id` | TEXT | Synthetic customer identifier | Not null, non-empty |
| `city` | TEXT | City attributed to the order/customer in this exercise | Not null, non-empty |
| `product` | TEXT | Product name | Not null, non-empty |
| `quantity` | INTEGER | Number of units in the record | Integer greater than zero |
| `unit_price` | NUMERIC(12,2) | Price per unit before discount | INR; zero or greater |
| `discount_percent` | NUMERIC(5,2) | Percentage reduction from gross value | 0 to 100 inclusive |
| `order_status` | TEXT | Lifecycle status for the record | Delivered, Cancelled, or Returned |

## Derived fields in `portfolio_retail.v_order_financials`

| Field | Formula | Treatment |
|---|---|---|
| `delivered_gross_value` | quantity × unit_price | Delivered rows only; zero otherwise |
| `delivered_discount_value` | gross value × discount percent / 100 | Delivered rows only; zero otherwise |
| `delivered_net_revenue` | gross value − discount value | Delivered rows only; zero otherwise |

## Grain warnings

A delivered record is counted as one delivered order record. If a real source contains multiple item rows per order, `COUNT(*)` is not the same as `COUNT(DISTINCT order_id)`. Customer counts use `COUNT(DISTINCT customer_id)`. City attribution is supplied by the synthetic data and does not imply shipping, billing, or customer-home city in a real system.
