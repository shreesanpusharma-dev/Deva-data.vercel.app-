-- Retail Sales & Revenue Analysis | version 1.1.0
-- Synthetic practice data only. No real customer or client information.
-- Safe to re-run: creates a dedicated schema/table and ignores existing order IDs.
-- This script does NOT drop, truncate, or delete existing tables or records.

BEGIN;

CREATE SCHEMA IF NOT EXISTS portfolio_retail;

CREATE TABLE IF NOT EXISTS portfolio_retail.orders (
    order_id          INTEGER PRIMARY KEY,
    order_date        DATE NOT NULL,
    customer_id       TEXT NOT NULL CHECK (length(trim(customer_id)) > 0),
    city              TEXT NOT NULL CHECK (length(trim(city)) > 0),
    product           TEXT NOT NULL CHECK (length(trim(product)) > 0),
    quantity          INTEGER NOT NULL CHECK (quantity > 0),
    unit_price        NUMERIC(12,2) NOT NULL CHECK (unit_price >= 0),
    discount_percent  NUMERIC(5,2) NOT NULL CHECK (discount_percent BETWEEN 0 AND 100),
    order_status      TEXT NOT NULL CHECK (order_status IN ('Delivered', 'Cancelled', 'Returned'))
);

INSERT INTO portfolio_retail.orders
    (order_id, order_date, customer_id, city, product, quantity,
     unit_price, discount_percent, order_status)
VALUES
    (1001, '2026-10-01', 'C001', 'Kolkata', 'Laptop', 1, 50000.00, 5.00, 'Delivered'),
    (1002, '2026-10-01', 'C002', 'Kolkata', 'Mouse', 2, 600.00, 0.00, 'Delivered'),
    (1003, '2026-10-02', 'C003', 'Delhi', 'Laptop', 1, 50000.00, 10.00, 'Delivered'),
    (1004, '2026-10-02', 'C004', 'Delhi', 'Keyboard', 3, 1200.00, 5.00, 'Delivered'),
    (1005, '2026-10-03', 'C005', 'Bengaluru', 'Monitor', 1, 18000.00, 0.00, 'Delivered'),
    (1006, '2026-10-03', 'C006', 'Kolkata', 'Monitor', 1, 18000.00, 5.00, 'Delivered'),
    (1007, '2026-10-04', 'C001', 'Kolkata', 'Keyboard', 2, 1200.00, 0.00, 'Cancelled'),
    (1008, '2026-10-04', 'C007', 'Delhi', 'Mouse', 4, 600.00, 0.00, 'Delivered'),
    (1009, '2026-10-05', 'C008', 'Bengaluru', 'Laptop', 1, 50000.00, 7.00, 'Delivered'),
    (1010, '2026-10-06', 'C009', 'Kolkata', 'Laptop', 1, 50000.00, 0.00, 'Returned'),
    (1011, '2026-10-07', 'C010', 'Delhi', 'Monitor', 2, 18000.00, 10.00, 'Delivered'),
    (1012, '2026-10-08', 'C011', 'Bengaluru', 'Keyboard', 2, 1200.00, 0.00, 'Delivered')
ON CONFLICT (order_id) DO NOTHING;

-- A reusable, non-materialized view centralises business metric definitions.
CREATE OR REPLACE VIEW portfolio_retail.v_order_financials AS
SELECT
    order_id,
    order_date,
    customer_id,
    city,
    product,
    quantity,
    unit_price,
    discount_percent,
    order_status,
    CASE WHEN order_status = 'Delivered'
         THEN ROUND(quantity * unit_price, 2)
         ELSE 0::NUMERIC END AS delivered_gross_value,
    CASE WHEN order_status = 'Delivered'
         THEN ROUND(quantity * unit_price * discount_percent / 100.0, 2)
         ELSE 0::NUMERIC END AS delivered_discount_value,
    CASE WHEN order_status = 'Delivered'
         THEN ROUND(quantity * unit_price * (1 - discount_percent / 100.0), 2)
         ELSE 0::NUMERIC END AS delivered_net_revenue
FROM portfolio_retail.orders;

COMMIT;

-- Quick setup verification.
SELECT COUNT(*) AS loaded_order_records
FROM portfolio_retail.orders;
