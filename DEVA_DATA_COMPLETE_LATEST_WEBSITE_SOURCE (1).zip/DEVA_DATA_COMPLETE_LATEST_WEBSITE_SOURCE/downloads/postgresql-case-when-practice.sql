-- PostgreSQL CASE WHEN practice
-- Synthetic learning data only. No real retailer/client data.
-- Safe to rerun: CREATE TABLE IF NOT EXISTS + ON CONFLICT DO NOTHING.
CREATE TABLE IF NOT EXISTS case_when_practice_orders (
    order_id INTEGER PRIMARY KEY,
    city TEXT NOT NULL,
    product TEXT NOT NULL,
    status TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    unit_price NUMERIC(10,2) NOT NULL,
    discount_pct NUMERIC(5,2) NOT NULL
);
INSERT INTO case_when_practice_orders
    (order_id, city, product, status, quantity, unit_price, discount_pct)
VALUES
    (1, 'Kolkata', 'Notebook', 'delivered', 2, 500, 10),
    (2, 'Kolkata', 'Pen', 'delivered', 5, 20, 0),
    (3, 'Kolkata', 'Bag', 'cancelled', 1, 1200, 15),
    (4, 'Delhi', 'Notebook', 'delivered', 1, 500, 20),
    (5, 'Delhi', 'Bag', 'returned', 1, 1200, 10),
    (6, 'Mumbai', 'Pen', 'pending', 10, 20, 5),
    (7, 'Mumbai', 'Notebook', 'delivered', 3, 500, 0),
    (8, 'Kolkata', 'Bag', 'delivered', 1, 1200, 25)
ON CONFLICT (order_id) DO NOTHING;

-- 1. Classify order statuses.
SELECT order_id, status,
    CASE
        WHEN status = 'delivered' THEN 'Completed'
        WHEN status = 'cancelled' THEN 'Cancelled'
        WHEN status = 'returned' THEN 'Returned'
        ELSE 'Pending'
    END AS order_group
FROM case_when_practice_orders
ORDER BY order_id;

-- 2. Create discount bands.
SELECT order_id, discount_pct,
    CASE
        WHEN discount_pct >= 20 THEN 'High discount'
        WHEN discount_pct >= 10 THEN 'Medium discount'
        WHEN discount_pct > 0 THEN 'Low discount'
        ELSE 'No discount'
    END AS discount_band
FROM case_when_practice_orders
ORDER BY order_id;

-- 3. Delivered net sales revenue by city.
-- Simplified sales metric, not profit or cash collected.
SELECT city,
    COUNT(*) FILTER (WHERE status = 'delivered') AS delivered_orders,
    ROUND(SUM(CASE
        WHEN status = 'delivered'
        THEN quantity * unit_price * (1 - discount_pct / 100.0)
        ELSE 0
    END), 2) AS net_sales_revenue
FROM case_when_practice_orders
GROUP BY city
ORDER BY city;

-- Expected revenue: Delhi 400.00, Kolkata 1900.00, Mumbai 1500.00.
-- Total = 3800.00.

-- 4. Practice: calculate delivered revenue by product.
SELECT product,
    ROUND(SUM(CASE
        WHEN status = 'delivered'
        THEN quantity * unit_price * (1 - discount_pct / 100.0)
        ELSE 0
    END), 2) AS net_sales_revenue
FROM case_when_practice_orders
GROUP BY product
ORDER BY net_sales_revenue DESC;
