-- PostgreSQL JOINs practice. Safe to re-run; no DROP statements.
CREATE TABLE IF NOT EXISTS demo_join_customers (
  customer_id INTEGER PRIMARY KEY,
  customer_name TEXT NOT NULL,
  city TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS demo_join_orders (
  order_id INTEGER PRIMARY KEY,
  customer_id INTEGER NOT NULL REFERENCES demo_join_customers(customer_id),
  order_date DATE NOT NULL,
  order_total NUMERIC(10,2) NOT NULL CHECK (order_total >= 0),
  status TEXT NOT NULL CHECK (status IN ('delivered','cancelled','returned'))
);
INSERT INTO demo_join_customers VALUES
 (1,'Asha','Kolkata'),(2,'Ravi','Delhi'),(3,'Neha','Bengaluru'),
 (4,'Imran','Kolkata'),(5,'Priya','Mumbai')
ON CONFLICT (customer_id) DO NOTHING;
INSERT INTO demo_join_orders VALUES
 (101,1,DATE '2026-10-01',1200,'delivered'),
 (102,1,DATE '2026-10-04',800,'delivered'),
 (103,2,DATE '2026-10-02',1500,'delivered'),
 (104,2,DATE '2026-10-05',500,'cancelled'),
 (105,3,DATE '2026-10-03',2200,'delivered'),
 (106,4,DATE '2026-10-06',900,'returned')
ON CONFLICT (order_id) DO NOTHING;

-- INNER JOIN: only rows with a match in both tables.
SELECT c.customer_name,o.order_id,o.order_total,o.status
FROM demo_join_customers c
INNER JOIN demo_join_orders o ON o.customer_id=c.customer_id
ORDER BY c.customer_id,o.order_id;

-- LEFT JOIN: retain all customers; filter delivered orders in ON.
SELECT c.customer_id,c.customer_name,c.city,
       COUNT(o.order_id) AS delivered_orders,
       COALESCE(SUM(o.order_total),0::numeric) AS delivered_revenue
FROM demo_join_customers c
LEFT JOIN demo_join_orders o
  ON o.customer_id=c.customer_id AND o.status='delivered'
GROUP BY c.customer_id,c.customer_name,c.city
ORDER BY delivered_revenue DESC,c.customer_name;

-- Customers with no order at all.
SELECT c.customer_id,c.customer_name,c.city
FROM demo_join_customers c
LEFT JOIN demo_join_orders o ON o.customer_id=c.customer_id
WHERE o.order_id IS NULL
ORDER BY c.customer_id;
