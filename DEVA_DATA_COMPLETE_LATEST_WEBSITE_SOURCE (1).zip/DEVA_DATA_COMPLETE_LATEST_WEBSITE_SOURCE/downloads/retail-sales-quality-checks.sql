-- Read-only diagnostics and regression assertions | version 1.1.0
-- Run setup.sql first. The final DO block raises an error if a core assertion fails.

-- A. Diagnostic checks: every failure count should be zero.
WITH checks AS (
    SELECT 'missing required fields' AS check_name, COUNT(*)::BIGINT AS failures
    FROM portfolio_retail.orders
    WHERE order_id IS NULL OR order_date IS NULL OR customer_id IS NULL
       OR city IS NULL OR product IS NULL OR order_status IS NULL
    UNION ALL
    SELECT 'duplicate order IDs', COUNT(*)::BIGINT
    FROM (
        SELECT order_id FROM portfolio_retail.orders
        GROUP BY order_id HAVING COUNT(*) > 1
    ) d
    UNION ALL
    SELECT 'invalid quantity / price / discount', COUNT(*)::BIGINT
    FROM portfolio_retail.orders
    WHERE quantity <= 0 OR unit_price < 0
       OR discount_percent NOT BETWEEN 0 AND 100
    UNION ALL
    SELECT 'unsupported order status', COUNT(*)::BIGINT
    FROM portfolio_retail.orders
    WHERE order_status NOT IN ('Delivered', 'Cancelled', 'Returned')
)
SELECT check_name, failures,
       CASE WHEN failures = 0 THEN 'PASS' ELSE 'FAIL' END AS result
FROM checks
ORDER BY check_name;

-- B. Dataset and revenue reconciliation.
SELECT
    COUNT(*) AS total_records,
    COUNT(*) FILTER (WHERE order_status = 'Delivered') AS delivered_records,
    COUNT(*) FILTER (WHERE order_status = 'Cancelled') AS cancelled_records,
    COUNT(*) FILTER (WHERE order_status = 'Returned') AS returned_records,
    SUM(delivered_gross_value) AS delivered_gross_value_inr,
    SUM(delivered_discount_value) AS delivered_discounts_inr,
    SUM(delivered_net_revenue) AS delivered_net_sales_revenue_inr
FROM portfolio_retail.v_order_financials;

-- C. Regression assertions. Failure raises an exception and stops the script.
DO $$
DECLARE
    v_total_records BIGINT;
    v_delivered_records BIGINT;
    v_cancelled_records BIGINT;
    v_returned_records BIGINT;
    v_gross NUMERIC(14,2);
    v_discounts NUMERIC(14,2);
    v_net NUMERIC(14,2);
    v_city_total NUMERIC(14,2);
BEGIN
    SELECT COUNT(*),
           COUNT(*) FILTER (WHERE order_status = 'Delivered'),
           COUNT(*) FILTER (WHERE order_status = 'Cancelled'),
           COUNT(*) FILTER (WHERE order_status = 'Returned'),
           SUM(delivered_gross_value),
           SUM(delivered_discount_value),
           SUM(delivered_net_revenue)
    INTO v_total_records, v_delivered_records, v_cancelled_records,
         v_returned_records, v_gross, v_discounts, v_net
    FROM portfolio_retail.v_order_financials;

    IF v_total_records <> 12 THEN
        RAISE EXCEPTION 'Expected 12 records; found %', v_total_records;
    END IF;
    IF v_delivered_records <> 10 OR v_cancelled_records <> 1 OR v_returned_records <> 1 THEN
        RAISE EXCEPTION 'Unexpected status counts: delivered %, cancelled %, returned %',
            v_delivered_records, v_cancelled_records, v_returned_records;
    END IF;
    IF v_gross <> 231600.00 OR v_discounts <> 15680.00 OR v_net <> 215920.00 THEN
        RAISE EXCEPTION 'Revenue reconciliation mismatch: gross %, discounts %, net %',
            v_gross, v_discounts, v_net;
    END IF;

    SELECT SUM(city_net) INTO v_city_total
    FROM (
        SELECT city, SUM(delivered_net_revenue) AS city_net
        FROM portfolio_retail.v_order_financials
        WHERE order_status = 'Delivered'
        GROUP BY city
    ) city_totals;

    IF v_city_total <> v_net THEN
        RAISE EXCEPTION 'City totals % do not reconcile to net revenue %', v_city_total, v_net;
    END IF;

    RAISE NOTICE 'PASS: all core dataset and revenue assertions passed.';
END $$;
