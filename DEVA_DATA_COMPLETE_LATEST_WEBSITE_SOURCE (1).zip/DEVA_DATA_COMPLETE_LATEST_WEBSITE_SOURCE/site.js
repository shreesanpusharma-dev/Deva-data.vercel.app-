(() => {
  'use strict';

  // Remove the old full-screen welcome gate before the page becomes interactive.
  document.documentElement.classList.remove('deva-home-welcome-pending', 'deva-sql-welcome-pending');
  const earlyWelcomeStyle = document.getElementById('deva-first-paint-welcome-style');
  if (earlyWelcomeStyle) earlyWelcomeStyle.remove();
  document.querySelectorAll('#deva-first-paint-welcome-gate').forEach(node => node.remove());
  if (document.body) document.body.style.visibility = 'visible';

  const header = document.querySelector('.site-header');

  // Accessible mobile navigation drawer.
  if (header) {
    const toggle = header.querySelector('.menu-toggle');
    const nav = header.querySelector('#primary-nav');
    const headerRight = header.querySelector('.header-right');
    const backdrop = header.querySelector('.menu-backdrop');
    if (toggle && nav && headerRight && backdrop) {
      const isOpen = () => header.classList.contains('is-menu-open');
      const closeMenu = (restoreFocus = false) => {
        header.classList.remove('is-menu-open');
        toggle.setAttribute('aria-expanded', 'false');
        toggle.setAttribute('aria-label', 'Open navigation');
        backdrop.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
        if (restoreFocus) toggle.focus({ preventScroll: true });
      };
      const openMenu = () => {
        header.classList.add('is-menu-open');
        toggle.setAttribute('aria-expanded', 'true');
        toggle.setAttribute('aria-label', 'Close navigation');
        backdrop.setAttribute('aria-hidden', 'false');
        document.body.style.overflow = 'hidden';
        window.requestAnimationFrame(() => {
          const firstLink = nav.querySelector('a[href]');
          if (firstLink) firstLink.focus({ preventScroll: true });
        });
      };
      toggle.addEventListener('click', () => isOpen() ? closeMenu() : openMenu());
      backdrop.addEventListener('click', () => closeMenu(true));
      headerRight.addEventListener('click', event => {
        if (event.target.closest('a')) closeMenu(false);
      });
      document.addEventListener('keydown', event => {
        if (!isOpen()) return;
        if (event.key === 'Escape') {
          event.preventDefault();
          closeMenu(true);
          return;
        }
        if (event.key === 'Tab') {
          const focusable = [
            toggle,
            ...headerRight.querySelectorAll('a[href]:not([tabindex="-1"])')
          ].filter(element => element.getClientRects().length > 0);
          if (!focusable.length) return;
          const first = focusable[0];
          const last = focusable[focusable.length - 1];
          if (event.shiftKey && document.activeElement === first) {
            event.preventDefault(); last.focus();
          } else if (!event.shiftKey && document.activeElement === last) {
            event.preventDefault(); first.focus();
          }
        }
      });
      document.addEventListener('click', event => {
        if (isOpen() && !header.contains(event.target)) closeMenu(false);
      });
      window.matchMedia('(min-width: 921px)').addEventListener('change', () => closeMenu());
    }
  }

  // Persistent active state for current page, selected section, and resume.
  const navs = [...document.querySelectorAll('header nav')];
  if (navs.length) {
    const navLinks = navs.flatMap(nav => [...nav.querySelectorAll('a')]);
    const standaloneItems = [...document.querySelectorAll('.site-header .resume-link')]
      .filter(link => !navLinks.includes(link));
    const managedItems = [...navLinks, ...standaloneItems];
    const normalizePath = path => {
      let decoded = decodeURIComponent(path || '/');
      while (decoded.length > 1 && decoded.endsWith('/')) decoded = decoded.slice(0, -1);
      return decoded || '/';
    };
    const currentPath = normalizePath(window.location.pathname);
    const getUrl = link => {
      try { return new URL(link.getAttribute('href'), window.location.href); }
      catch { return null; }
    };
    const setActive = (selected, currentType = 'location') => {
      managedItems.forEach(link => link.classList.toggle('is-active', link === selected));
      navLinks.forEach(link => {
        if (link === selected) link.setAttribute('aria-current', currentType);
        else link.removeAttribute('aria-current');
      });
    };
    const routeCandidates = managedItems.map(link => {
      const url = getUrl(link);
      if (!url || url.origin !== window.location.origin || url.hash) return null;
      const path = normalizePath(url.pathname);
      const exact = path === currentPath;
      const sectionRoot = path !== '/' && currentPath.startsWith(path + '/');
      return (exact || sectionRoot) ? { link, score: path.length } : null;
    }).filter(Boolean).sort((a, b) => b.score - a.score);
    if (routeCandidates.length) setActive(routeCandidates[0].link, 'page');

    const sectionItems = navLinks.map(link => {
      const url = getUrl(link);
      if (!url || url.origin !== window.location.origin ||
          normalizePath(url.pathname) !== currentPath || !url.hash) return null;
      const target = document.getElementById(decodeURIComponent(url.hash.slice(1)));
      return target ? { link, target } : null;
    }).filter(Boolean);

    let pendingSection = null;
    const updateActiveSection = () => {
      if (!sectionItems.length) return;
      const markerOffset = Math.min(190, window.innerHeight * 0.24);
      if (pendingSection) {
        const targetTop = pendingSection.target.getBoundingClientRect().top;
        if (targetTop > markerOffset + 2) return;
        setActive(pendingSection.link, 'location');
        pendingSection = null;
      }
      const marker = window.scrollY + markerOffset;
      let current = null;
      for (const item of sectionItems) {
        const top = item.target.getBoundingClientRect().top + window.scrollY;
        if (top <= marker) current = item;
      }
      if (current) setActive(current.link, 'location');
      else if (window.scrollY < 120) {
        managedItems.forEach(link => link.classList.remove('is-active'));
        navLinks.forEach(link => link.removeAttribute('aria-current'));
      }
    };
    managedItems.forEach(link => {
      link.addEventListener('click', () => {
        const url = getUrl(link);
        if (!url || url.origin !== window.location.origin) return;
        const samePage = normalizePath(url.pathname) === currentPath;
        const section = sectionItems.find(item => item.link === link);
        if (section) {
          pendingSection = section;
          setActive(link, 'location');
          return;
        }
        pendingSection = null;
        setActive(link, samePage && url.hash ? 'location' : 'page');
      });
    });
    if (sectionItems.length) {
      const clearPendingOnUserInput = () => { pendingSection = null; };
      window.addEventListener('wheel', clearPendingOnUserInput, { passive: true });
      window.addEventListener('touchstart', clearPendingOnUserInput, { passive: true });
      window.addEventListener('scroll', updateActiveSection, { passive: true });
      window.addEventListener('hashchange', updateActiveSection);
      window.addEventListener('pageshow', updateActiveSection);
      updateActiveSection();
    }
  }

  // Keep the back-to-top control visible until the reader returns near the top.
  const backToTop = document.querySelector('.back-to-top');
  if (backToTop) {
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    const syncButton = () => backToTop.classList.toggle('is-visible', window.scrollY > 360);
    window.addEventListener('scroll', syncButton, { passive: true });
    window.addEventListener('pageshow', syncButton);
    window.addEventListener('resize', syncButton, { passive: true });
    backToTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: reducedMotion.matches ? 'auto' : 'smooth' }));
    syncButton();
  }



  // Restore the welcome introduction without delaying the page or locking its scroll.
  const showWelcomeIntro = () => {
    let path = window.location.pathname;
    while (path.length > 1 && path.endsWith('/')) path = path.slice(0, -1);
    const isHome = path === '/';
    const isSql = path === '/guides' || path.startsWith('/guides/');
    if (!isHome && !isSql) return;
    const kind = isHome ? 'home' : 'sql';
    const storageKey = 'deva-welcome-intro-nonblocking-v1-' + kind;
    try {
      if (window.sessionStorage.getItem(storageKey) === 'shown') return;
      window.sessionStorage.setItem(storageKey, 'shown');
    } catch (_) {
      if (window.__devaWelcomeIntroShown && window.__devaWelcomeIntroShown[kind]) return;
      window.__devaWelcomeIntroShown = window.__devaWelcomeIntroShown || {};
      window.__devaWelcomeIntroShown[kind] = true;
    }
    const style = document.createElement('style');
    style.id = 'deva-welcome-intro-style-' + kind;
    style.textContent = `
      #deva-welcome-intro-layer { position:fixed; inset:0; z-index:10000; display:grid; place-items:center; padding:18px; background:rgba(8,14,25,.76); opacity:0; transition:opacity .24s ease; cursor:pointer; }
      #deva-welcome-intro-layer.is-visible { opacity:1; }
      #deva-welcome-intro-card { position:relative; display:grid; place-items:center; text-align:center; width:min(540px,calc(100vw - 36px)); min-height:220px; padding:38px 32px; border:1px solid rgba(255,255,255,.24); border-radius:24px; color:#f8fafc; cursor:default; background:linear-gradient(145deg,rgba(255,255,255,.17),rgba(255,255,255,.075)); box-shadow:0 22px 56px rgba(0,0,0,.24),inset 0 1px 0 rgba(255,255,255,.2); opacity:0; transform:translateY(8px) scale(.99); transition:opacity .24s ease,transform .24s ease; }
      #deva-welcome-intro-card.is-visible { opacity:1; transform:translateY(0) scale(1); }
      #deva-welcome-intro-card.is-closing { opacity:0; transform:translateY(-5px) scale(.99); }
      #deva-welcome-intro-title { display:block; margin:0 0 9px; color:#fff; font-family:"Noto Serif Devanagari","Nirmala UI",Georgia,serif; font-size:clamp(46px,8vw,68px); font-weight:600; line-height:1.3; }
      #deva-welcome-intro-kicker { margin:0 0 8px; color:#d8c7a4; font-size:10px; font-weight:800; letter-spacing:.16em; text-transform:uppercase; }
      #deva-welcome-intro-copy { max-width:410px; margin:0; color:#e1e7ee; font:500 15px/1.65 Inter,"Segoe UI",Arial,sans-serif; }
      #deva-welcome-intro-close { position:absolute; top:12px; right:12px; width:32px; height:32px; display:grid; place-items:center; border:1px solid rgba(255,255,255,.3); border-radius:50%; background:rgba(255,255,255,.08); color:white; font:400 20px/1 Inter,"Segoe UI",Arial,sans-serif; cursor:pointer; }
      #deva-welcome-intro-close:hover { background:rgba(255,255,255,.18); }
      #deva-welcome-intro-close:focus-visible { outline:2px solid #e6d5af; outline-offset:3px; }
      @media(max-width:520px) { #deva-welcome-intro-card { width:calc(100vw - 28px); min-height:195px; padding:34px 22px; border-radius:20px; } #deva-welcome-intro-copy { font-size:14px; } }
      @media(prefers-reduced-motion:reduce) { #deva-welcome-intro-layer,#deva-welcome-intro-card { transition:none !important; } #deva-welcome-intro-card { transform:none !important; } }
    `;
    document.head.appendChild(style);
    const layer = document.createElement('div');
    layer.id = 'deva-welcome-intro-layer';
    const card = document.createElement('section');
    card.id = 'deva-welcome-intro-card';
    card.setAttribute('role','dialog');
    card.setAttribute('aria-modal','true');
    card.setAttribute('aria-labelledby','deva-welcome-intro-title');
    if (isHome) {
      card.innerHTML = '<p id="deva-welcome-intro-kicker">Welcome</p><span id="deva-welcome-intro-title" lang="hi">नमस्ते</span><p id="deva-welcome-intro-copy">I’m glad you’re here.</p><button id="deva-welcome-intro-close" type="button" aria-label="Close introduction">×</button>';
    } else {
      card.innerHTML = '<p id="deva-welcome-intro-kicker">A note from Deva</p><span id="deva-welcome-intro-title">Welcome to SQL Guides</span><p id="deva-welcome-intro-copy">Explore practical PostgreSQL examples, clear explanations and business questions at your own pace.</p><button id="deva-welcome-intro-close" type="button" aria-label="Close introduction">×</button>';
    }
    layer.appendChild(card);
    document.body.appendChild(layer);
    let closed = false;
    let autoClose = 0;
    let removeTimer = 0;
    const closeButton = card.querySelector('#deva-welcome-intro-close');
    const cleanup = () => { document.removeEventListener('keydown', onKeydown); layer.remove(); style.remove(); };
    const dismiss = () => {
      if (closed) return;
      closed = true;
      if (autoClose) window.clearTimeout(autoClose);
      if (removeTimer) window.clearTimeout(removeTimer);
      document.removeEventListener('keydown', onKeydown);
      layer.classList.remove('is-visible');
      card.classList.remove('is-visible');
      card.classList.add('is-closing');
      removeTimer = window.setTimeout(cleanup, 260);
    };
    const onKeydown = event => {
      if (event.key === 'Escape') { event.preventDefault(); dismiss(); }
      if (event.key === 'Tab') { event.preventDefault(); closeButton.focus({preventScroll:true}); }
    };
    closeButton.addEventListener('click',dismiss);
    layer.addEventListener('click',event=>{if(event.target===layer)dismiss();});
    document.addEventListener('keydown',onKeydown);
    window.requestAnimationFrame(()=>{ layer.classList.add('is-visible'); card.classList.add('is-visible'); closeButton.focus({preventScroll:true}); });
    autoClose = window.setTimeout(dismiss, isHome ? 4200 : 4600);
  };
  showWelcomeIntro();

  // Functional, accessible profile introduction carousel.
  document.querySelectorAll('[data-profile-swipe-root]').forEach(root => {
    if (root.dataset.profileSwipeReady === 'true') return;
    const track = root.querySelector('[data-profile-track]');
    const viewport = root.querySelector('[data-profile-viewport]');
    const slides = Array.from(root.querySelectorAll('[data-profile-slide]'));
    const dots = Array.from(root.querySelectorAll('[data-profile-go]'));
    const previous = root.querySelector('[data-profile-prev]');
    const next = root.querySelector('[data-profile-next]');
    const count = root.querySelector('[data-profile-count]');
    const hint = root.querySelector('[data-profile-hint]');
    const status = root.querySelector('[data-profile-status]');
    if (!track || !viewport || slides.length < 2) return;
    root.dataset.profileSwipeReady = 'true';
    if (hint) hint.classList.add('profile-swipe-hint');
    let activeIndex = Math.max(0, slides.findIndex(slide => slide.classList.contains('is-active')));
    let pointerStart = null;
    const update = (requestedIndex, announce = true) => {
      activeIndex = Math.max(0, Math.min(slides.length - 1, requestedIndex));
      track.style.setProperty('--step', String(activeIndex));
      slides.forEach((slide, index) => {
        const active = index === activeIndex;
        slide.classList.toggle('is-active', active);
        slide.setAttribute('aria-hidden', String(!active));
        slide.inert = !active;
      });
      dots.forEach((dot, index) => {
        if (index === activeIndex) dot.setAttribute('aria-current', 'step');
        else dot.removeAttribute('aria-current');
      });
      if (count) count.textContent = String(activeIndex + 1).padStart(2, '0') + ' / ' + String(slides.length).padStart(2, '0');
      if (previous) previous.disabled = activeIndex === 0;
      if (next) next.disabled = activeIndex === slides.length - 1;
      if (hint) hint.textContent = activeIndex === slides.length - 1 ? 'End of introduction' : 'Swipe or use arrows';
      if (announce && status) status.textContent = 'Profile page ' + (activeIndex + 1) + ' of ' + slides.length + '.';
    };
    dots.forEach((dot, index) => dot.addEventListener('click', () => update(index)));
    if (previous) previous.addEventListener('click', () => update(activeIndex - 1));
    if (next) next.addEventListener('click', () => update(activeIndex + 1));
    viewport.addEventListener('keydown', event => {
      if (event.key === 'ArrowRight' || event.key === 'ArrowLeft' || event.key === 'Home' || event.key === 'End') {
        event.preventDefault();
        if (event.key === 'ArrowRight') update(activeIndex + 1);
        else if (event.key === 'ArrowLeft') update(activeIndex - 1);
        else if (event.key === 'Home') update(0);
        else update(slides.length - 1);
      }
    });
    viewport.addEventListener('pointerdown', event => {
      if (event.pointerType === 'mouse') return;
      pointerStart = { id: event.pointerId, x: event.clientX };
    }, { passive: true });
    viewport.addEventListener('pointerup', event => {
      if (!pointerStart || pointerStart.id !== event.pointerId) return;
      const distance = event.clientX - pointerStart.x;
      pointerStart = null;
      if (Math.abs(distance) < 38) return;
      update(activeIndex + (distance < 0 ? 1 : -1));
    }, { passive: true });
    viewport.addEventListener('pointercancel', () => { pointerStart = null; }, { passive: true });
    update(activeIndex, false);
  });

  const profileMotionStyle = document.createElement('style');
  profileMotionStyle.id = 'deva-profile-motion-style';
  profileMotionStyle.textContent = `
    .profile-swipe-track { transition-duration: .32s !important; will-change: transform; }
    .profile-swipe-slide { transition-duration: .18s !important; }
    @media (prefers-reduced-motion: reduce) {
      .profile-swipe-track, .profile-swipe-slide, .profile-swipe-dots button { transition: none !important; }
    }
  `;
  document.head.appendChild(profileMotionStyle);

  // Refined, personal hero typography with a warm plum accent.
  const heroEyebrow = document.querySelector('.intro-grid > div > .eyebrow');
  const heroName = document.querySelector('.intro-grid > div > #page-title');
  if (heroEyebrow && heroName) {
    heroEyebrow.innerHTML = 'Hello, <span class="deva-hero-im">I’m</span>';

    // Use local system fonts to avoid an extra external font request during page load.
    const greetingStyle = document.createElement('style');
    greetingStyle.id = 'deva-human-greeting-style';
    greetingStyle.textContent = `
      .intro-grid > div > .eyebrow {
        display: block !important;
        width: max-content !important;
        margin: 0 0 8px !important;
        color: #704060 !important;
        font-family: Inter, "Segoe UI", Arial, sans-serif !important;
        font-size: clamp(22px, 1.85vw, 25px) !important;
        font-style: normal !important;
        font-weight: 600 !important;
        letter-spacing: -0.035em !important;
        line-height: 1.25 !important;
        text-align: left !important;
        text-transform: none !important;
      }
      .intro-grid > div > #page-title {
        margin: 0 !important;
        color: #17243a !important;
        font-family: Inter, "Segoe UI", Arial, sans-serif !important;
        font-size: clamp(44px, 5.2vw, 64px) !important;
        font-style: normal !important;
        font-weight: 800 !important;
        letter-spacing: -0.055em !important;
        line-height: 1.08 !important;
        text-align: left !important;
        text-wrap: balance;
      }
      .intro-grid > div > .eyebrow::before,
      .intro-grid > div > .eyebrow::after {
        content: none !important;
        display: none !important;
      }
      @media (max-width: 600px) {
        .intro-grid > div > .eyebrow {
          font-size: 22px !important;
          margin-bottom: 8px !important;
        }
        .intro-grid > div > #page-title {
          font-size: clamp(36px, 10.25vw, 44px) !important;
          letter-spacing: -0.05em !important;
          line-height: 1.1 !important;
        }
      }
    `;
    document.head.appendChild(greetingStyle);
  }



  const cleanText = (selector, value, root = document) => { const node = root.querySelector(selector); if (node) node.textContent = value; };
  const route = window.location.pathname.replace(/\/+$/, '') || '/';
  if (route === '/guides') {
    const intro = document.querySelector('.path-intro');
    if (intro) {
      intro.querySelector('.path-kicker')?.remove();
      intro.querySelector('.eyebrow')?.remove();
      intro.querySelector('.path-note')?.remove();
      cleanText('h1', 'SQL learning paths', intro);
      cleanText('.dek', 'Choose Beginner if you are new to SQL. Choose Advanced if you already know joins, grouping and subqueries.', intro);
    }
    const beginnerCard = document.querySelector('.track-card.beginner');
    const advancedCard = document.querySelector('.track-card.advanced');
    if (beginnerCard) {
      cleanText('p', 'Learn SQL from the start. Each topic has a short explanation, a worked PostgreSQL query and a practice task.', beginnerCard);
      cleanText('.track-label', '01 · Beginner', beginnerCard);
      cleanText('.track-action span', 'View beginner lessons', beginnerCard);
    }
    if (advancedCard) {
      cleanText('p', 'For learners who know the basics. Practise window functions, CTEs, cohort analysis and query performance.', advancedCard);
      cleanText('.track-label', '02 · Advanced', advancedCard);
      cleanText('.track-action span', 'View advanced lessons', advancedCard);
    }
    cleanText('.path-method .path-section-title', 'How the lessons work');
    cleanText('.path-method .path-section-copy', 'Each lesson includes an explanation, a worked query, expected output and a task to try.');
    const titles = document.querySelectorAll('.path-section-title');
    if (titles.length) titles[titles.length - 1].textContent = 'Looking for a particular topic?';
  }
  const beginnerTrack = document.querySelector('.sql-track-page[data-sql-progress="beginner"]');
  if (beginnerTrack) {
    cleanText('h1', 'Learn PostgreSQL from the beginning.', beginnerTrack);
    cleanText('.dek', 'Start with databases and tables, then practise SELECT, filters, joins and grouping. Each lesson includes a worked query and a task to try.', beginnerTrack);
  }
  const advancedTrack = document.querySelector('.sql-track-page[data-sql-progress="advanced"]');
  if (advancedTrack) {
    cleanText('h1', 'Advanced PostgreSQL for data analysis.', advancedTrack);
    cleanText('.dek', 'Practise window functions, CTEs, cohort analysis and query performance. Start here if you already know joins, aggregations and subqueries.', advancedTrack);
  }


  const naturalVisualStyle = document.createElement('style');
  naturalVisualStyle.id = 'deva-natural-visual-style';
  naturalVisualStyle.textContent = `
    body {background-image:radial-gradient(ellipse at 8% 0%,rgba(23,107,99,.018),transparent 32rem),radial-gradient(ellipse at 96% 34%,rgba(16,36,58,.018),transparent 38rem) !important;background-size:auto,auto !important;background-repeat:no-repeat,no-repeat !important;}
    .intro {background-image:linear-gradient(180deg,#fff 0%,#f7f8fa 100%) !important;}
    .profile-swipe:before {background:#b7a27b !important;}
    .profile-swipe-top,.profile-swipe-footnote {color:#c8c4bb !important;}
    .profile-swipe-list li>b {color:#d3c8b2 !important;border-color:#ffffff55 !important;}
    .profile-swipe-dots button {width:14px !important;height:4px !important;border-radius:2px !important;background:#89909a !important;box-shadow:none !important;}
    .profile-swipe-dots button[aria-current=step] {width:24px !important;background:#b7a27b !important;box-shadow:none !important;}
    header nav a.is-active,header nav a[aria-current="page"],header nav a[aria-current="location"] {color:#343b45 !important;background:#f4f0e7 !important;border-color:#e5dccb !important;box-shadow:inset 0 -2px 0 #b7a27b !important;}
    header nav a.is-active:hover,header nav a[aria-current="page"]:hover,header nav a[aria-current="location"]:hover {color:#222a34 !important;background:#eee8db !important;}
    @media(max-width:640px){.site-header.is-menu-open .nav a.is-active,.site-header.is-menu-open .nav a[aria-current="page"],.site-header.is-menu-open .nav a[aria-current="location"]{color:#343b45 !important;background:#f4f0e7 !important;border-color:#e5dccb !important;box-shadow:inset 3px 0 0 #b7a27b !important;}}
    .back-to-top {transition:opacity .18s ease,transform .18s ease,visibility 0s linear .18s,box-shadow .18s ease !important;}
    .back-to-top.is-visible {opacity:1 !important;visibility:visible !important;pointer-events:auto !important;transform:translate3d(0,0,0) scale(1) !important;transition:opacity .18s ease,transform .18s ease,visibility 0s,box-shadow .18s ease !important;}
    .path-intro .path-kicker,.path-intro > .eyebrow,.path-note {display:none !important;}
    .track-card,.track-card.beginner {background:#faf7f0 !important;color:#242a32 !important;border-color:#e5ddcc !important;box-shadow:0 8px 22px rgba(45,40,29,.055) !important;}
    .track-card.advanced {background:#f3eee2 !important;color:#242a32 !important;border-color:#ddd1b9 !important;box-shadow:0 8px 22px rgba(45,40,29,.07) !important;}
    .track-card.advanced p,.track-card.advanced .track-meta,.track-card.advanced .track-points li {color:#56544e !important;}
    .track-label,.advanced .track-label {color:#6d5b39 !important;background:#f4eedf !important;border:1px solid #e1d4b8 !important;border-radius:5px !important;letter-spacing:.055em !important;}
    .track-icon,.advanced .track-icon {background:#eee7d8 !important;color:#776744 !important;border-color:#dfd3bc !important;border-radius:10px !important;}
    .track-card p,.track-points li,.track-card.advanced .track-points li {color:#56544e !important;}
    .track-points li:before,.track-card.advanced .track-points li:before {color:#9b8357 !important;}
    .track-action {color:#6d5b39 !important;}
    .track-card:hover {transform:translateY(-2px) !important;border-color:#c9b995 !important;box-shadow:0 12px 27px rgba(45,40,29,.10) !important;}
    .track-card:focus-visible {outline:3px solid #9b8357 !important;outline-offset:4px;}
    .sql-overline:before {background:#b7a27b !important;}
    .sql-editor-status:before {background:#b7a27b !important;box-shadow:none !important;}
    .sql-progress-track i,.sql-card-progress i {background:#b7a27b !important;}
    .sql-complete-btn[aria-pressed=true] {border-color:#ddcfb4 !important;background:#f5f0e5 !important;color:#685634 !important;}
    .sql-road-num {background:#f3eee2 !important;color:#776744 !important;}
    .sql-mini-bar {background:linear-gradient(180deg,#cbb98f,#9c8356) !important;}
    .sql-flow-arrow {color:#b7a27b !important;}
    .sql-insight-panel {border-color:#e5ddcc !important;background:#faf7f0 !important;}
    .sql-insight-panel b,.sql-next-link,.sql-challenge-label {color:#806a42 !important;}
  `;
  document.head.appendChild(naturalVisualStyle);


  // Subtle entrance and ambient background motion for the white homepage hero.
  const heroMotionStyle = document.createElement('style');
  heroMotionStyle.id = 'deva-hero-motion-style';
  heroMotionStyle.textContent = `
    .intro {
      position: relative !important;
      isolation: isolate;
    }
    .intro::before {
      content: "";
      position: absolute;
      inset: 0;
      z-index: 0;
      pointer-events: none;
      background:
        radial-gradient(ellipse at 18% 22%, rgba(207,190,153,.15), transparent 42%),
        radial-gradient(ellipse at 86% 74%, rgba(195,210,226,.18), transparent 46%);
      opacity: .72;
      transform: translate3d(-1.2%,0,0) scale(1.025);
      animation: deva-hero-light-drift 16s ease-in-out infinite alternate;
    }
    .intro-grid {
      position: relative;
      z-index: 1;
    }
    .intro-grid > div > .eyebrow {
      font-size: clamp(30px, 2.6vw, 36px) !important;
      font-weight: 650 !important;
      letter-spacing: -.045em !important;
      line-height: 1.08 !important;
      margin-bottom: 9px !important;
      animation: deva-hero-greeting-in .68s cubic-bezier(.2,.75,.25,1) both;
    }
    .intro-grid > div > #page-title {
      animation: deva-hero-title-in .72s cubic-bezier(.2,.75,.25,1) .09s both;
    }
    @keyframes deva-hero-greeting-in {
      from { opacity: 0; transform: translate3d(0,10px,0); }
      to { opacity: 1; transform: translate3d(0,0,0); }
    }
    @keyframes deva-hero-title-in {
      from { opacity: 0; transform: translate3d(0,8px,0); }
      to { opacity: 1; transform: translate3d(0,0,0); }
    }
    @keyframes deva-hero-light-drift {
      from { transform: translate3d(-1.2%,0,0) scale(1.025); }
      to { transform: translate3d(1.2%,.7%,0) scale(1.055); }
    }
    .intro-grid > div > .eyebrow .deva-hero-im {
      display: inline-block;
      margin-left: .12em;
      color: #805a72;
      font-family: "Segoe Script", "Brush Script MT", "URW Chancery L", cursive !important;
      font-size: .96em;
      font-style: italic;
      font-weight: 500;
      letter-spacing: -.055em;
      line-height: 1;
      transform: translateY(.035em);
    }
    @media (max-width: 600px) {
      .intro-grid > div > .eyebrow {
        font-size: clamp(29px, 7.2vw, 33px) !important;
        margin-bottom: 8px !important;
      }
      .intro-grid > div > .eyebrow .deva-hero-im {
        font-size: .92em;
      }
    }
    @media (prefers-reduced-motion: reduce) {
      .intro::before { animation: none !important; transform: none !important; }
      .intro-grid > div > .eyebrow,
      .intro-grid > div > #page-title { animation: none !important; }
    }
  `;
  document.head.appendChild(heroMotionStyle);


  // Keep the RSS feed available to subscribers and feed readers, but remove its visible footer links.
  document.querySelectorAll('body a[href]').forEach((link) => {
    const rawHref = link.getAttribute('href') || '';
    try {
      const feedUrl = new URL(rawHref, window.location.href);
      if (feedUrl.origin === window.location.origin && feedUrl.pathname === '/feed.xml') {
        link.remove();
      }
    } catch (_) {}
  });

  // Add discoverable PostgreSQL function references to both learning tracks.
  const sqlTrack = document.querySelector('main.sql-track-page[data-sql-progress]');
  if (sqlTrack && !document.getElementById('sql-functions-reference')) {
    const isAdvanced = sqlTrack.getAttribute('data-sql-progress') === 'advanced';
    const section = document.createElement('section');
    section.id = 'sql-functions-reference';
    section.className = 'sql-functions-reference';
    section.setAttribute('aria-labelledby', 'sql-functions-heading');

    const beginnerMarkup = `
      <p class="eyebrow">Practical function library</p>
      <h2 id="sql-functions-heading">Common PostgreSQL functions every analyst should know</h2>
      <p class="sql-functions-intro">Use this as a lookup sheet alongside the 12 lessons. These are the core functions you'll repeatedly use while cleaning data, preparing metrics and analysing business performance.</p>
      <div class="sql-functions-grid">
        <article class="sql-function-card">
          <span class="tag">Text functions</span><h3>Clean and reshape strings</h3>
          <p><code>LOWER</code>, <code>UPPER</code>, <code>INITCAP</code>, <code>LENGTH</code>, <code>TRIM</code>, <code>CONCAT</code>, <code>REPLACE</code>, <code>SPLIT_PART</code>, <code>SUBSTRING</code>, <code>LEFT</code>, <code>RIGHT</code>.</p>
          <pre><code>SELECT LOWER(TRIM(full_name)) AS clean_name,
       LENGTH(TRIM(full_name)) AS name_length
FROM customers;</code></pre>
        </article>
        <article class="sql-function-card">
          <span class="tag">Numeric functions</span><h3>Calculate and round values</h3>
          <p><code>ROUND</code>, <code>ABS</code>, <code>CEIL</code>, <code>FLOOR</code>, <code>MOD</code>, <code>POWER</code>, <code>GREATEST</code>, <code>LEAST</code>.</p>
          <pre><code>SELECT ROUND(unit_price, 2) AS rounded_price,
       ABS(quantity - 10) AS distance_from_ten,
       GREATEST(unit_price, 100) AS reference_value
FROM orders;</code></pre>
        </article>
        <article class="sql-function-card">
          <span class="tag">Date and time</span><h3>Work with dates and periods</h3>
          <p><code>CURRENT_DATE</code>, <code>CURRENT_TIMESTAMP</code>, <code>NOW()</code>, <code>DATE_TRUNC</code>, <code>EXTRACT</code>, <code>AGE</code>, <code>TO_CHAR</code>.</p>
          <pre><code>SELECT DATE_TRUNC('month', order_date)::date AS month_start,
       EXTRACT(YEAR FROM order_date) AS order_year,
       TO_CHAR(order_date, 'YYYY-MM') AS month_label
FROM orders;</code></pre>
        </article>
        <article class="sql-function-card">
          <span class="tag">NULL and conversion</span><h3>Handle missing values safely</h3>
          <p><code>COALESCE</code>, <code>NULLIF</code>, <code>CAST</code> and PostgreSQL's <code>::</code> cast syntax. Use <code>NULLIF</code> to protect divisions from zero denominators.</p>
          <pre><code>SELECT COALESCE(discount_pct, 0) AS safe_discount,
       NULLIF(quantity, 0) AS nonzero_quantity
FROM orders;</code></pre>
        </article>
        <article class="sql-function-card">
          <span class="tag">Aggregate functions</span><h3>Summarise multiple rows</h3>
          <p><code>COUNT</code>, <code>COUNT(DISTINCT ...)</code>, <code>SUM</code>, <code>AVG</code>, <code>MIN</code>, <code>MAX</code> and <code>STRING_AGG</code>. The <code>FILTER (WHERE ...)</code> clause creates conditional aggregates.</p>
          <pre><code>SELECT COUNT(*) AS order_lines,
       COUNT(DISTINCT customer_id) AS buyers,
       ROUND(SUM(quantity * unit_price), 2) AS gross_sales,
       ROUND(AVG(unit_price), 2) AS avg_unit_price
FROM orders;</code></pre>
        </article>
        <article class="sql-function-card">
          <span class="tag">Conditional expressions</span><h3>Apply business rules</h3>
          <p><code>CASE WHEN</code> is an expression, not a function. Pair it with <code>COALESCE</code>, <code>GREATEST</code> and <code>LEAST</code> to implement transparent business rules.</p>
          <pre><code>SELECT order_id,
       CASE WHEN quantity * unit_price >= 10000
            THEN 'High value' ELSE 'Regular'
       END AS value_band
FROM orders;</code></pre>
        </article>
      </div>
      <p class="sql-functions-note"><strong>Learning scope:</strong> this is a practical analyst reference, not every built-in PostgreSQL function. PostgreSQL has additional specialised functions and operators for areas such as arrays, JSON, text search, ranges, UUIDs and administration.</p>
      <p class="sql-functions-links"><a href="https://www.postgresql.org/docs/current/functions.html" target="_blank" rel="noopener noreferrer">Official PostgreSQL function and operator reference ↗</a></p>
    `;

    const advancedMarkup = `
      <p class="eyebrow">Advanced PostgreSQL reference</p>
      <h2 id="sql-functions-heading">Advanced functions and analytical patterns</h2>
      <p class="sql-functions-intro">Use this index alongside the 16 advanced modules. It groups the higher-value PostgreSQL functions and operators used for ranking, time-series analysis, segmentation, semi-structured data and analytical reporting.</p>
      <div class="sql-functions-grid">
        <article class="sql-function-card">
          <span class="tag">Window functions</span><h3>Rank, compare and look across rows</h3>
          <p><code>ROW_NUMBER</code>, <code>RANK</code>, <code>DENSE_RANK</code>, <code>NTILE</code>, <code>LAG</code>, <code>LEAD</code>, <code>FIRST_VALUE</code>, <code>LAST_VALUE</code>, <code>NTH_VALUE</code>, plus aggregate functions with <code>OVER</code>.</p>
          <pre><code>SELECT city, order_id, order_date,
       ROW_NUMBER() OVER (
         PARTITION BY city
         ORDER BY order_date DESC, order_id DESC
       ) AS latest_order_rank,
       LAG(order_date) OVER (
         PARTITION BY customer_id ORDER BY order_date
       ) AS previous_order_date
FROM orders;</code></pre>
        </article>
        <article class="sql-function-card">
          <span class="tag">Advanced aggregates</span><h3>Build statistical and conditional metrics</h3>
          <p><code>FILTER</code>, <code>STRING_AGG</code>, <code>ARRAY_AGG</code>, <code>JSONB_AGG</code>, <code>PERCENTILE_CONT</code>, <code>PERCENTILE_DISC</code> and <code>MODE() WITHIN GROUP</code>. Combine with <code>ROLLUP</code>, <code>CUBE</code> and <code>GROUPING SETS</code>.</p>
          <pre><code>SELECT city,
       PERCENTILE_CONT(0.5) WITHIN GROUP (
         ORDER BY quantity * unit_price
       ) AS median_line_value
FROM orders
GROUP BY city;</code></pre>
        </article>
        <article class="sql-function-card">
          <span class="tag">Array functions</span><h3>Work with lists stored in rows</h3>
          <p><code>ARRAY_AGG</code>, <code>UNNEST</code>, <code>CARDINALITY</code>, <code>ARRAY_LENGTH</code>, <code>STRING_TO_ARRAY</code> and <code>ARRAY_TO_STRING</code>.</p>
          <pre><code>SELECT city,
       ARRAY_AGG(DISTINCT product_name ORDER BY product_name) AS products
FROM orders
GROUP BY city;</code></pre>
        </article>
        <article class="sql-function-card">
          <span class="tag">JSON and JSONB</span><h3>Read and construct flexible records</h3>
          <p><code>JSONB_BUILD_OBJECT</code>, <code>JSONB_AGG</code>, <code>JSONB_ARRAY_ELEMENTS</code>, <code>JSONB_EACH</code>, <code>JSONB_OBJECT_KEYS</code>; operators include <code>-&gt;</code>, <code>-&gt;&gt;</code>, <code>@&gt;</code> and <code>#&gt;&gt;</code>.</p>
          <pre><code>SELECT JSONB_BUILD_OBJECT(
         'order_id', order_id,
         'city', city,
         'gross_value', quantity * unit_price
       ) AS order_document
FROM orders;</code></pre>
        </article>
        <article class="sql-function-card">
          <span class="tag">Time series</span><h3>Generate periods and align events</h3>
          <p><code>GENERATE_SERIES</code>, <code>DATE_TRUNC</code>, <code>EXTRACT</code>, <code>AGE</code> and <code>AT TIME ZONE</code>. Use <code>DATE_TRUNC</code> for calendar buckets and explicit time-zone rules for timestamp reporting.</p>
          <pre><code>SELECT GENERATE_SERIES(
         DATE '2026-01-01',
         DATE '2026-06-01',
         INTERVAL '1 month'
       )::date AS month_start;</code></pre>
        </article>
        <article class="sql-function-card">
          <span class="tag">Text and search</span><h3>Normalise and search text</h3>
          <p><code>REGEXP_REPLACE</code>, <code>REGEXP_MATCHES</code>, <code>TO_TSVECTOR</code>, <code>PLAINTO_TSQUERY</code>, <code>WEBSEARCH_TO_TSQUERY</code> and <code>TS_RANK</code>.</p>
          <pre><code>SELECT product_name,
       TS_RANK(
         TO_TSVECTOR('english', product_name),
         PLAINTO_TSQUERY('english', 'office chair')
       ) AS relevance
FROM orders
WHERE TO_TSVECTOR('english', product_name)
      @@ PLAINTO_TSQUERY('english', 'office chair')
ORDER BY relevance DESC;</code></pre>
        </article>
      </div>
      <p class="sql-functions-note"><strong>Also remember:</strong> <code>EXPLAIN (ANALYZE, BUFFERS)</code> is a query-plan command, not a function. The advanced lessons already cover indexes, execution plans, transactions, recursive CTEs, LATERAL joins, cohorts, funnels, RFM and production readiness.</p>
      <p class="sql-functions-links"><a href="https://www.postgresql.org/docs/current/functions.html" target="_blank" rel="noopener noreferrer">Official PostgreSQL function and operator reference ↗</a></p>
    `;

    section.innerHTML = isAdvanced ? advancedMarkup : beginnerMarkup;

    if (!document.getElementById('deva-sql-function-reference-style')) {
      const referenceStyle = document.createElement('style');
      referenceStyle.id = 'deva-sql-function-reference-style';
      referenceStyle.textContent = `
        .sql-functions-reference{margin:34px 0 40px;padding:clamp(20px,3.5vw,34px);background:#fff;border:1px solid #dce3eb;border-radius:10px}
        .sql-functions-reference h2{margin:0 0 10px;font-size:clamp(24px,3vw,32px);line-height:1.2;letter-spacing:-.035em}
        .sql-functions-intro{max-width:760px;margin:0 0 22px;color:#526174;font-size:14px;line-height:1.75}
        .sql-functions-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
        .sql-function-card{min-width:0;padding:17px;background:#f8f9fb;border:1px solid #e2e7ee;border-radius:8px}
        .sql-function-card h3{margin:7px 0 8px;font-size:17px;line-height:1.3}
        .sql-function-card p{margin:8px 0;color:#465568;font-size:13px;line-height:1.7}
        .sql-function-card pre{margin:12px 0 0;white-space:pre;overflow-x:auto}
        .sql-function-card .tag{display:inline-block;color:#806a42;font-weight:800}
        .sql-functions-note{margin:20px 0 8px;padding:12px 14px;background:#f5f1e8;border-left:3px solid #b7a27b;color:#4b5360;font-size:13px;line-height:1.7}
        .sql-functions-links{margin:12px 0 0;font-size:13px;font-weight:700}
        .sql-functions-links a{color:#315fe8}
        .deva-function-reference-links{margin:16px 0 24px;padding:15px 18px;background:#f5f1e8;border-left:3px solid #b7a27b;border-radius:6px;color:#465568;font-size:13px;line-height:1.7}
        .deva-function-reference-links a{color:#2449bd;font-weight:750;margin-right:14px}
        @media(max-width:640px){.sql-functions-grid{grid-template-columns:1fr}.sql-functions-reference{padding:20px 16px}.sql-function-card{padding:15px}}
      `;
      document.head.appendChild(referenceStyle);
    }

    const lessonIndex = sqlTrack.querySelector('.lesson-index');
    if (lessonIndex) {
      const navLink = document.createElement('a');
      navLink.href = '#sql-functions-reference';
      navLink.textContent = isAdvanced ? 'Function and operator reference' : 'Common SQL function reference';
      navLink.setAttribute('data-deva-function-reference-link', '');
      lessonIndex.appendChild(navLink);
    }

    const capstone = sqlTrack.querySelector('.track-capstone');
    if (capstone) capstone.parentNode.insertBefore(section, capstone);
    else sqlTrack.appendChild(section);
  }

  // Make the reference easy to discover from the SQL learning-path hub.
  if ((window.location.pathname === '/guides/' || window.location.pathname === '/guides') && !document.querySelector('.deva-function-reference-links')) {
    const guideCards = document.querySelector('main .cards');
    if (guideCards) {
      const quickLinks = document.createElement('div');
      quickLinks.className = 'deva-function-reference-links';
      quickLinks.innerHTML = '<strong>Looking for a function by name?</strong> Use the quick references inside each course: <a href="/guides/beginner/#sql-functions-reference">Beginner function reference</a><a href="/guides/advanced/#sql-functions-reference">Advanced function reference</a>';
      guideCards.insertAdjacentElement('afterend', quickLinks);
    }
  }


  // Keep the Beginner starter lab isolated from unrelated user tables.
  const beginnerStarterCode = document.querySelector('#b1 .lesson-body pre code');
  if (beginnerStarterCode && !beginnerStarterCode.dataset.safeNamespace) {
    const existingStarterSql = beginnerStarterCode.textContent || '';
    const firstDrop = 'DROP TABLE IF EXISTS orders;';
    if (existingStarterSql.trimStart().startsWith(firstDrop)) {
      beginnerStarterCode.textContent =
        'CREATE SCHEMA IF NOT EXISTS deva_sql_learning_lab;\\n' +
        'SET search_path TO deva_sql_learning_lab;\\n' +
        existingStarterSql;
      beginnerStarterCode.dataset.safeNamespace = 'true';
      const starterPre = beginnerStarterCode.closest('pre');
      if (starterPre && !starterPre.previousElementSibling?.classList.contains('deva-sql-safety-note')) {
        const safetyNote = document.createElement('p');
        safetyNote.className = 'note deva-sql-safety-note';
        safetyNote.textContent = 'Safety: this starter lab switches into the dedicated deva_sql_learning_lab schema before creating or replacing its practice tables. It will not drop tables in your default public schema.';
        starterPre.parentNode.insertBefore(safetyNote, starterPre);
      }
    }
  }
})();
