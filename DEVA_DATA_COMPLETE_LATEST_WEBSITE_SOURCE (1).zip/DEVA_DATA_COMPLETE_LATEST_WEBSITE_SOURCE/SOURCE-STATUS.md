# DEVA DATA | Complete Latest Website Source

Package date: 11 November 2026

This ZIP contains the full saved website release candidate recovered from the Vercel workspace snapshot `deva-portfolio-responsive-fix-v2` and the `skills-release-candidate` source directory, plus the requested logo integration. It includes the homepage, all saved static pages, SQL Studio, browser SQL worker, styles, scripts, data, downloadable SQL/data resources, guides, case study and resources page.

## Included brand marks

PostgreSQL, SQL, Python, Power BI, Microsoft Excel, Claude, Codex, LinkedIn and WhatsApp Business. The site's existing HTML5, CSS3 and JavaScript marks are also retained.

## Important source-status note

This is the latest complete saved working source available in the recovered workspace, not a byte-for-byte export of the currently deployed production build. The saved candidate contains newer Skills content that had not yet been promoted to the live production domain when this ZIP was assembled. The live website was not changed during this packaging task.

## Logo asset note

The existing PostgreSQL, Python, Power BI and Excel SVG assets are reused from the saved website source. SQL, Codex, Claude, LinkedIn and WhatsApp Business marks are standalone SVG assets added to this package. SQL is a generic database-language mark. The Codex, Power BI, Excel and WhatsApp Business designs are vector treatments for this site, not a claim that they are official vendor-issued logo-kit files.

## Structure

- `index.html`: portfolio homepage
- `assets/`: skills and brand logo SVGs
- `guides/`: PostgreSQL learning guides
- `projects/`: retail sales analysis case study
- `resources/`: downloads and reproducibility resources
- `downloads/`: SQL, CSV, Python and project package files
- `data/`: practice dataset
- `site.js`, `sql-studio.js`, `sql-paths.js`: interactive site behaviour
- `responsive-system.css`, `sql-studio.css`, `sql-paths.css`, `contact-card.css`: styles

## Deploying this source

Unzip the folder and deploy its contents as the root of the existing Vercel project. Preserve the existing project settings, domains, and team scope. Review the ZIP before promoting it to production.
